<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Home</title>
    <link rel="stylesheet" href="style_homepage.css">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap' rel='stylesheet'>
</head>
<body>
    <div class="container">
        <div class="box">
            <a href="display_students.php">DISPLAY STUDENTS</a>
        </div>
        <div class="box">
            <a href="add_student.php">ADD STUDENT</a>
        </div>
    </div>
</body>
</html>
