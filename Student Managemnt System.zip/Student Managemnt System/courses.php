<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Courses</title>
    <link rel="stylesheet" href="style_attendance.css">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <h1>Courses</h1>
        <div class="input-box">
        <table>
    <thead>
        <tr>
            <th>Course ID</th>
            <th>Course Name</th>
            <th>Instructor</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>Mathematics</td>
            <td>Prof. Ahmed</td>
        </tr>
        <tr>
            <td>2</td>
            <td>Science</td>
            <td>Prof. Muhammad</td>
        </tr>
        <tr>
            <td>3</td>
            <td>Physics</td>
            <td>Prof. Ali</td>
        </tr>
        <tr>
            <td>4</td>
            <td>Chemistry</td>
            <td>Prof. Fatima</td>
        </tr>
        <tr>
            <td>5</td>
            <td>Biology</td>
            <td>Prof. Aisha</td>
        </tr>
        <tr>
            <td>6</td>
            <td>History</td>
            <td>Prof. Yusuf</td>
        </tr>
        <tr>
            <td>7</td>
            <td>Geography</td>
            <td>Prof. Ibrahim</td>
        </tr>
        <tr>
            <td>8</td>
            <td>English</td>
            <td>Prof. Hassan</td>
        </tr>
        <tr>
            <td>9</td>
            <td>Computer Science</td>
            <td>Prof. Omar</td>
        </tr>
        <tr>
            <td>10</td>
            <td>Art</td>
            <td>Prof. Khalid</td>
        </tr>
        <tr>
            <td>11</td>
            <td>Music</td>
            <td>Prof. Aysha</td>
        </tr>
        <tr>
            <td>12</td>
            <td>Physical Education</td>
            <td>Prof. Layla</td>
        </tr>
        <tr>
            <td>13</td>
            <td>Economics</td>
            <td>Prof. Amir</td>
        </tr>
        <tr>
            <td>14</td>
            <td>Psychology</td>
            <td>Prof. Khadija</td>
        </tr>
        <tr>
            <td>15</td>
            <td>Sociology</td>
            <td>Prof. Nabil</td>
        </tr>
    </tbody>
</table>

        </div>
    </div>
</body>
</html>
