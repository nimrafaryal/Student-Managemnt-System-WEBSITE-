<?php include("connection.php"); 
$id =  $_GET['id'];
$query = "SELECT * FROM add_student where ID='$id'";
$data = mysqli_query($conn, $query);

$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student Details</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <form action="#" method="POST">
            <h1>Update Student Details</h1>
            <div class="input-box">
                <input type="text" placeholder="First Name" value="<?php echo $result['fname'] ?>" name="fname" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="text" placeholder="Last Name" value="<?php echo $result['lname'] ?>" name="lname" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="text" placeholder="Father Name" value="<?php echo $result['father_name'] ?>" name="father_name" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="date" placeholder="Date of Birth" value="<?php echo $result['dob'] ?>" name="dob" required>
            </div>
            <div class="input-box">
                <label for="gender">Gender</label>
                <select id="gender" name="gender" value="" required>
                    <option value="" disabled selected>Choose your gender</option>
                    <option value="male"
                      <?php 
                        if($result['gender'] == 'male')
                        {
                            echo "selected";
                        }
                        ?>
                    >Male</option>
                    <option value="female"
                    <?php 
                        if($result['gender'] == 'female')
                        {
                            echo "selected";
                        }
                        ?>
                    >Female</option>
                    <option value="other"
                    <?php 
                        if($result['gender'] == 'other')
                        {
                            echo "selected";
                        }
                        ?>
                    >Other</option>
                </select>
            </div>

            <div class="input-box">
                <input type="text" placeholder="Address" value="<?php echo $result['address'] ?>" name="address" required>
                <i class='bx bxs-home'></i>
            </div>
            <div class="input-box">
                <input type="email" placeholder="Email" value="<?php echo $result['email'] ?>" name="email" required>
                <i class='bx bxs-envelope'></i>
            </div>
            <div class="input-box">
                <input type="tel" placeholder="Phone No." value="<?php echo $result['phone'] ?>" name="phone" required>
                <i class='bx bxs-phone'></i>
            </div>
            <input type="submit" class="btn" name="update" value="Update"></input>
        </form>
    </div>
</body>
</html>

<?php 
if(isset($_POST['update'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $father_name = $_POST['father_name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query= "UPDATE add_student set fname='$fname',lname='$lname',father_name='$father_name',dob='$dob',gender='$gender',address='$address',email='$email',phone='$phone' WHERE ID='$id'";
    $data = mysqli_query($conn, $query);

    if($data){
        echo "DATA UPDATED SUCCESSFULLY!!";
        ?>
        <meta http-equiv="refresh" content="0;url =http://localhost/project/display_students.php" />
        <?php
    } else {
        echo "FAILED :(" . mysqli_error($conn);
    }
}
?>
