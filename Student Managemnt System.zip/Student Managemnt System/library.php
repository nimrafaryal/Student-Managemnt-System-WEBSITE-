<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <link rel="stylesheet" href="style_library.css">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <h1>Library Management System</h1>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>ISBN</th>
                    <th>Copies Available</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $books = array(
                    "biology" => array(
                        array(
                            "title" => "The Selfish Gene",
                            "author" => "Richard Dawkins",
                            "isbn" => "9780192860927",
                            "copies" => 5
                        ),
                        array(
                            "title" => "Sapiens: A Brief History of Humankind",
                            "author" => "Yuval Noah Harari",
                            "isbn" => "9780062316097",
                            "copies" => 3
                        ),
                        array(
                            "title" => "The Immortal Life of Henrietta Lacks",
                            "author" => "Rebecca Skloot",
                            "isbn" => "9781400052189",
                            "copies" => 4
                        ),
                        array(
                            "title" => "Guns, Germs, and Steel: The Fates of Human Societies",
                            "author" => "Jared Diamond",
                            "isbn" => "9780393317558",
                            "copies" => 6
                        ),
                        array(
                            "title" => "The Origin of Species",
                            "author" => "Charles Darwin",
                            "isbn" => "9780140439120",
                            "copies" => 8
                        ),
                        array(
                            "title" => "The Botany of Desire: A Plant's-Eye View of the World",
                            "author" => "Michael Pollan",
                            "isbn" => "9780375760396",
                            "copies" => 5
                        ),
                        array(
                            "title" => "The Hidden Life of Trees: What They Feel, How They Communicate – Discoveries from a Secret World",
                            "author" => "Peter Wohlleben",
                            "isbn" => "9781771642484",
                            "copies" => 2
                        ),
                        array(
                            "title" => "The Sixth Extinction: An Unnatural History",
                            "author" => "Elizabeth Kolbert",
                            "isbn" => "9780805092998",
                            "copies" => 3
                        ),
                        array(
                            "title" => "The Brain That Changes Itself: Stories of Personal Triumph from the Frontiers of Brain Science",
                            "author" => "Norman Doidge",
                            "isbn" => "9780143113102",
                            "copies" => 7
                        ),
                        array(
                            "title" => "The Vital Question: Energy, Evolution, and the Origins of Complex Life",
                            "author" => "Nick Lane",
                            "isbn" => "9780393352979",
                            "copies" => 4
                        )
                    ),
                    "physics" => array(
                        array(
                            "title" => "A Brief History of Time",
                            "author" => "Stephen Hawking",
                            "isbn" => "9780553380163",
                            "copies" => 7
                        ),
                        array(
                            "title" => "The Elegant Universe",
                            "author" => "Brian Greene",
                            "isbn" => "9780393338102",
                            "copies" => 4
                        ),
                        array(
                            "title" => "Astrophysics for People in a Hurry",
                            "author" => "Neil deGrasse Tyson",
                            "isbn" => "9780393609394",
                            "copies" => 5
                        ),
                        array(
                            "title" => "Seven Brief Lessons on Physics",
                            "author" => "Carlo Rovelli",
                            "isbn" => "9780399184413",
                            "copies" => 3
                        ),
                        array(
                            "title" => "Physics of the Future: How Science Will Shape Human Destiny and Our Daily Lives by the Year 2100",
                            "author" => "Michio Kaku",
                            "isbn" => "9780385530804",
                            "copies" => 6
                        ),
                        array(
                            "title" => "Black Hole Blues and Other Songs from Outer Space",
                            "author" => "Janna Levin",
                            "isbn" => "9780307958198",
                            "copies" => 4
                        ),
                        array(
                            "title" => "The Particle at the End of the Universe: How the Hunt for the Higgs Boson Leads Us to the Edge of a New World",
                            "author" => "Sean Carroll",
                            "isbn" => "9780525953593",
                            "copies" => 3
                        ),
                        array(
                            "title" => "Quantum Mechanics: The Theoretical Minimum",
                            "author" => "Leonard Susskind, Art Friedman",
                            "isbn" => "9780465062904",
                            "copies" => 2
                        ),
                        array(
                            "title" => "The Fabric of the Cosmos: Space, Time, and the Texture of Reality",
                            "author" => "Brian Greene",
                            "isbn" => "9780375727207",
                            "copies" => 5
                        ),
                        array(
                            "title" => "The God Particle: If the Universe Is the Answer, What Is the Question?",
                            "author" => "Leon Lederman",
                            "isbn" => "9780618711680",
                            "copies" => 6
                        )
                    ),
                    "chemistry" => array(
                        array(
                            "title" => "The Disappearing Spoon",
                            "author" => "Sam Kean",
                            "isbn" => "9780316051637",
                            "copies" => 2
                        ),
                        array(
                            "title" => "The Elements: A Visual Exploration of Every Known Atom in the Universe",
                            "author" => "Theodore Gray",
                            "isbn" => "9781579128142",
                            "copies" => 6
                        ),
                        array(
                            "title" => "The Periodic Table",
                            "author" => "Primo Levi",
                            "isbn" => "9780805210415",
                            "copies" => 4
                        ),
                        array(
                            "title" => "Molecules: The Elements and the Architecture of Everything",
                            "author" => "Theodore Gray",
                            "isbn" => "9780316480581",
                            "copies" => 5
                        ),
                        array(
                            "title" => "The Chemistry Book: From Gunpowder to Graphene, 250 Milestones in the History of Chemistry",
                            "author" => "Derek B. Lowe",
                            "isbn" => "9781402789612",
                            "copies" => 3
                        ),
                        array(
                            "title" => "Napoleon's Buttons: How 17 Molecules Changed History",
                            "author" => "Penny Le Couteur, Jay Burreson",
                            "isbn" => "9781585423316",
                            "copies" => 4
                        ),
                        array(
                            "title" => "Mendeleyev's Dream: The Quest for the Elements",
                            "author" => "Paul Strathern",
                            "isbn" => "9780140287297",
                            "copies" => 3
                        ))
                );

                foreach ($books as $category => $category_books) {
                    foreach ($category_books as $book) {
                        echo "<tr>";
                        echo "<td>{$book['title']}</td>";
                        echo "<td>{$book['author']}</td>";
                        echo "<td>{$book['isbn']}</td>";
                        echo "<td>{$book['copies']}</td>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
