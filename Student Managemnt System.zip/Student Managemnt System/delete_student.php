<?php include("connection.php"); 
$id =  $_GET['id']; 
$query= "DELETE FROM add_student WHERE ID='$id'";
$data = mysqli_query($conn,$query);
if($data){
    // echo "RECORD DELETED SUCCESSFULLY!";
    ?>
    <meta http-equiv="refresh" content="0;url =http://localhost/project/display_students.php" />
    <?php
}
else{
    echo"DELETION FAILED!";
}
?>