<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Grades</title>
    <link rel="stylesheet" href="style_attendance.css">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <h1>Grades</h1>
        <div class="input-box">
            <table>
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Example data, replace with your dynamic data -->
                    <tr>
                        <td>4</td>
                        <td>KHURRAM ShEHZAD</td>
                        <td>B-</td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>fatima</td>
                        <td>A</td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>Misbah Fatima</td>
                        <td>B+</td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>Alishba Fatima</td>
                        <td>A</td>
                    </tr>
                    <tr>
                        <td>11</td>
                        <td>Wasim Kundi</td>
                        <td>B-</td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>Saira Khan</td>
                        <td>A</td>
                    </tr>
                    <tr>
                        <td>13</td>
                        <td>Khan Muhammad</td>
                        <td>A</td>
                    </tr>
                    <tr>
                        <td>14</td>
                        <td>Ahmad Ali</td>
                        <td>B+</td>
                    </tr>
                    <!-- Add more rows as needed -->
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
