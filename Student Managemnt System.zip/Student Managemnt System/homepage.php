<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Home</title>
    <link rel="stylesheet" href="style_homepage.css">
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap' rel='stylesheet'>
</head>
<body>
    <div class="container">
        <div class="box">
            <a href="students.php">Students</a>
        </div>
        <div class="box">
            <a href="attendance.php">Attendance</a>
        </div>
        <div class="box">
            <a href="grades.php">Grades</a>
        </div>
        <div class="box">
            <a href="courses.php">Courses</a>
        </div>
        <div class="box">
            <a href="library.php">Library</a>
        </div>
    </div>
</body>
</html>
