<?php include ("connection.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Students</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('img1.jpg') no-repeat;
            background-size: cover;
            background-position: center;
            color: white; /* Set default text color to white */
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #fff;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }

        tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .container {
            max-width: 100%;
            padding: 20px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        
        
    </style>
</head>

<body>
    <div class="container">
        <h1>Student Records</h1>
        <?php
        $query = "SELECT * FROM add_student";
        $data = mysqli_query($conn, $query);

        $total = mysqli_num_rows($data);

        if ($total != 0) {
            ?>
            <table>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Father Name</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Phone No.</th>
                    <th>Operations</th>
                </tr>
                <?php
                while ($result = mysqli_fetch_assoc($data)) {
                    echo "
                    <tr>
                        <td>" . $result['ID'] . "</td>
                        <td>" . $result['fname'] . "</td>
                        <td>" . $result['lname'] . "</td>
                        <td>" . $result['father_name'] . "</td>
                        <td>" . $result['dob'] . "</td>
                        <td>" . $result['gender'] . "</td>
                        <td>" . $result['address'] . "</td>
                        <td>" . $result['email'] . "</td>
                        <td>" . $result['phone'] . "</td>
                        <td><a href='update_student.php?id=$result[ID]'><input type='submit' value='Update' class='btn'></a>
                        <a href='delete_student.php?id=$result[ID]'><input type='submit' value='Delete' class='btn' onclick='return checkdelete()'></a>
                        </td>   
                    </tr>";
                } 
                ?>
            </table>
        <?php
        } else {
            echo "No Records Found";
        }
        ?>
    </div>
</body>
<script>
    function checkdelete(){
      return confirm('Are you sure you want to delete this record??');
    }
</script>

</html>

