<?php  
 error_reporting(); //to hide the error
  $servername = "localhost";
  $username  = "root";
  $password ="";
  $dbname = "std_management";
   
  $conn = mysqli_connect($servername,$username,$password,$dbname);
  if($conn){
    //echo"connection successful!";   //commented it so that it does not show anything if connected
  }
  else{
    echo"connection failed";
  }
?>