<?php include("connection.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Form</title>
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
        <form action="#" method="POST">
            <h1>Student Registration Form</h1>
            <div class="input-box">
                <input type="text" placeholder="First Name" name="fname" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="text" placeholder="Last Name" name="lname" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="text" placeholder="Father Name" name="father_name" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="date" placeholder="Date of Birth" name="dob" required>
            </div>
            <div class="input-box">
                <label for="gender">Gender</label>
                <select id="gender" name="gender" required>
                    <option value="" disabled selected>Choose your gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div class="input-box">
                <input type="text" placeholder="Address" name="address" required>
                <i class='bx bxs-home'></i>
            </div>
            <div class="input-box">
                <input type="email" placeholder="Email" name="email" required>
                <i class='bx bxs-envelope'></i>
            </div>
            <div class="input-box">
                <input type="tel" placeholder="Phone No." name="phone" required>
                <i class='bx bxs-phone'></i>
            </div>
            <input type="submit" class="btn" name="register" value="Register"></input>
        </form>
    </div>
</body>
</html>

<?php 
if(isset($_POST['register'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $father_name = $_POST['father_name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $query = "INSERT INTO ADD_STUDENT (fname, lname, father_name, dob, gender, address, email, phone) VALUES ('$fname', '$lname', '$father_name', '$dob', '$gender', '$address', '$email', '$phone')";
    $data = mysqli_query($conn, $query);

    if($data){
        // echo "DATA INSERTED SUCCESSFULLY!!";
        ?>
    <meta http-equiv="refresh" content="0;url =http://localhost/project/display_students.php" />
    <?php
    } else {
        echo "FAILED :(" . mysqli_error($conn);
    }
}
?>